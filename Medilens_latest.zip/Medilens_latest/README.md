python -m venv venv
.\venv\Scripts\activate


pip install Flask Flask-CORS python-dotenv