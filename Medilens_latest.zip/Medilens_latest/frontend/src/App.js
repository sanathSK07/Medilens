
import Navbar from './components/Navbar'

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // Import BrowserRouter, Routes, Route
import HomePage from './Pages/HomePage'; // Corrected import to HomePage
import './index.css'; 

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50 flex flex-col items-center py-8">
        <h1 className="text-5xl font-extrabold text-gray-800 mb-8">
          <Navbar />
        </h1>

        <main className="w-full max-w-4xl px-4">
          <Routes>
            <Route path="/" element={<HomePage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
